<?php

require_once '../models/Patient.php';

class PatientsController {
    private Patient $patientModel;

    public function __construct(PDO $db)
    {
        $this->patientModel = new Patient($db);
    }

    public function getPatients(): array
    {
        return $this->patientModel->getPatients();
    }

    public function getPatient(int $id)
    {
        return $this->patientModel->getById($id);
    }

    public function createPatient(array $data): bool
    {
        return $this->patientModel->create($data);
    }

    public function updatePatient(int $id, array $data): bool
    {
        return $this->patientModel->update($id, $data);
    }

    public function deletePatient($id): bool
    {
        return $this->patientModel->delete($id);
    }
}