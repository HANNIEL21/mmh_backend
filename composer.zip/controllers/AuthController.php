<?php

require_once __DIR__ . "/../models/Auth.php";
require_once __DIR__ . "/../utils/sendmail.php";

class UserController
{
    private $auth;

    public function __construct($db)
    {
        $this->auth = new Auth($db);
    }

    public function createAccount($data)
    {
        // Validate the input data
        $validationResult = $this->auth->validate($data);

        if ($validationResult['status'] === 'error') {
            return $validationResult; // Return the validation error
        }

        // Check if email already exists
        if ($this->auth->verifyUser($data['email'])) {
            return ["status" => "error", "message" => "Email already exists."];
        }

        // Create account
        $result = $this->auth->createAccount($data);

        if ($result) {
            return ["status" => "success", "message" => "Account created successfully."];
        } else {
            return ["status" => "error", "message" => "Failed to create account."];
        }
    }


    public function login($data)
    {
        return $this->auth->login($data);
    }

    public function deleteAccount($id)
    {
        return $this->auth->deleteAccount($id) ?
            ["status" => "success", "message" => "Account deleted successfully."] :
            ["status" => "error", "message" => "Failed to delete account."];
    }

    public function getUser($id)
    {
        $user = $this->auth->getUser($id);
        if ($user) {
            return ["status" => "success", "data" => $user];
        } else {
            return ["status" => "error", "message" => "User not found."];
        }
    }

    public function updateAccount($id, $data)
    {
        $data['updated'] = date('Y-m-d H:i:s');
        return $this->auth->updateAccount($id, $data) ?
            ["status" => "success", "message" => "Account updated successfully."] :
            ["status" => "error", "message" => "Failed to update account."];
    }

    public function resetPassword($data)
    {
        // Validate the email address
        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            http_response_code(400); // Bad Request
            echo json_encode(array("message" => "Invalid email address"));
            return;
        }

        // Generate a reset token
        $token = $this->auth->generateResetToken($data);

        if ($token) {
            // Prepare the email body
            $mailBody = "<html><body>
            <h2>Password Reset Request</h2>
            <p>Dear user,</p>
            <p>You have requested to reset your password. Please use the following token to reset your password:</p>
            <p><strong>Token: $token</strong></p>
            <p>This token will expire in 30 minutes.</p>
            <p>If you did not request a password reset, please ignore this email.</p>
            <p>Best regards,<br>Mercy Memorial Hospital</p>
        </body></html>";

            // Send the email
            if (sendMail($data['email'], "Your password reset token", $mailBody)) {
                http_response_code(200); // OK
                $response = array("message" => "OTP successfully sent to " . $data['email'], "token" => $token);
            } else {
                http_response_code(500); // Internal Server Error
                $response = array("message" => "Failed to send OTP email.");
            }
        } else {
            http_response_code(500); // Internal Server Error
            $response = array("message" => "Failed to generate reset token.");
        }

        return $response;
    }

    public function getToken($token){

        // Validate the email address
        if (empty($token)) {
            http_response_code(400); // Bad Request
            echo json_encode(array("message" => "Invalid TOKEN"));
            return;
        }

        return $this->auth->getToken($token);
    }

    public function updatePassword($data){
        return $this->auth->updatePassword($data);
    }





}
