<?php

class Auth
{
    private $conn;
    private $table = "users";

    public function __construct($db)
    {
        $this->conn = $db;
    }
    public function validate($data)
    {
        $requiredFields = ['firstname', 'lastname', 'email', 'password', 'phone', 'role'];
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                // Handle missing fields, return false or throw an exception
                return ["status" => "error", "message" => "Field '$field' is required and cannot be empty"];
            }
        }
        // Return true if all fields are valid
        return ["status" => "success", "message" => "Validation successful"];
    }
    public function verifyUser($email)
    {
        $query = "SELECT * FROM " . $this->table . " WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":email", $email);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC) !== false;
    }
    public function createAccount($data)
    {
        $query = "INSERT INTO " . $this->table . " (firstname, lastname, email, password, phone, role, created_at, updated_at) 
                  VALUES (:firstname, :lastname, :email, :password, :phone, :role, :created, :updated)";
        $stmt = $this->conn->prepare($query);
        $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);

        $stmt->bindParam(":firstname", $data['firstname']);
        $stmt->bindParam(":lastname", $data['lastname']);
        $stmt->bindParam(":email", $data['email']);
        $stmt->bindParam(":password", $hashedPassword);
        $stmt->bindParam(":phone", $data['phone']);
        $stmt->bindParam(":role", $data['role']);
        $stmt->bindParam(":created", $data['created']);
        $stmt->bindParam(":updated", $data['updated']);
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
    public function login($data)
    {
        $query = "SELECT * FROM " . $this->table . " WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":email", $data['email']);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            if (password_verify($data['password'], $user['password'])) {
                unset($user['password']); // Remove password from user data
                return ["status" => "success", "data" => $user];
            } else {
                return ["status" => "error", "message" => "Invalid password."];
            }
        } else {
            return ["status" => "error", "message" => "User not found."];
        }
    }
    public function deleteAccount($id)
    {
        $query = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
    public function getUser($id)
    {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function updateAccount($id, $data)
    {
        $query = "UPDATE " . $this->table . " SET firstname = :firstname, lastname = :lastname, email = :email, 
                  phone = :phone, role = :role, updated_at = :updated WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":firstname", $data['firstname']);
        $stmt->bindParam(":lastname", $data['lastname']);
        $stmt->bindParam(":email", $data['email']);
        $stmt->bindParam(":phone", $data['phone']);
        $stmt->bindParam(":role", $data['role']);
        $stmt->bindParam(":updated", $data['updated']);
        $stmt->bindParam(":id", $id);

        return $stmt->execute();
    }

    public function updatePassword($data)
    {
        $query = "UPDATE " . $this->table . " SET password = :password, updated_at = :updated WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);
        
        $stmt->bindParam(":id", $data['id']);
        $stmt->bindParam(":password", $hashedPassword);
        $stmt->bindParam(":updated", $data['updated']);

        return $stmt->execute();
    }

    public function generateResetToken($data)
    {
        $email = $data['email'];
        $token = random_int(100000, 999999); // Generate a random 6-digit token
        $tokenHash = hash('sha256', $token); // Hash the token
        $expiry = date("Y-m-d H:i:s", time() + 60 * 30); // 30 minutes from now

        $query = "UPDATE " . $this->table . " SET hashed_token = :hash, hashed_token_expires_at = :expiry WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':expiry', $expiry);
        $stmt->bindParam(':hash', $tokenHash);

        if ($stmt->execute()) {
            return $token;
        } else {
            return false;
        }
    }

    public function getToken($token)
    {
        $hashedToken = hash('sha256', $token);

        $query = "SELECT * FROM " . $this->table . " WHERE hashed_token = :token";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':token', $hashedToken);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $result; 
        } else {
            return false; 
        }
    }


}
